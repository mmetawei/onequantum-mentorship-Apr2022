#Battleship Board Game <br>
This package will count the number of battleships on the board, no adjacent battleships are allowed.